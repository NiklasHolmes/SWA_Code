﻿namespace Dojo3_Abgabe
{
    public class MyItemBase
    {
        public int Id { get; set; }
        public double Name { get; set; }
        public string Description { get; set; }
        public string Room { get; set; }
        public double PosX { get; set; }
        public double PosY { get; set; }

    }
}