﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dojo3_Abgabe
{
    public class Delegates
    {
        public delegate void Informer();   //Bauplan für den Zeiger auf eine Methode
    }
}
